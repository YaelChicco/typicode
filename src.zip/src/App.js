import React from 'react';
import { BrowserRouter, Routes, Route, Redirect } from "react-router-dom";
import LoginPage from './pages/LoginPage';
import AppPage from './pages/AppPage';
import NotFound from './pages/NotFound';
import UserInfo from './pages/UserInfo';
import Todos from './pages/Todos';
import Albums from './pages/Albums';
import Posts from './pages/Posts';

import './App.css';


function App() {
  return (
  <BrowserRouter>
    <Routes className='navbar'>
    {/* <Route path="/" element={<Redirect to="/login" />} /> */}
    <Route path="/login" element={<LoginPage />} />
    <Route path="/application" element={<AppPage />} />
    <Route path="/info">
      <Route path=":id" element={<UserInfo />} />
    </Route>
    <Route path="/todos">
      <Route path=":id" element={<Todos />} />
    </Route>
    <Route path="/posts">
      <Route path=":id" element={<Posts />} />
    </Route>
    <Route path="/albums">
      <Route path=":id" element={<Albums />} />
    </Route>
    <Route path="*" element={<NotFound />} />
    </Routes>
  </BrowserRouter>

  );
}

export default App;
