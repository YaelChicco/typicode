import React, { useState } from 'react';
import { Link, Route, BrowserRouter ,useNavigate} from 'react-router-dom';
import './appPage.css'
function ApplicationPage({ logout }) {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('username')));
  let navigate=useNavigate();
  
  const handleLogout=()=>{
    localStorage.clear();
    navigate("/login");
  }
    return (
      <div>
        <nav>
          <ul>
            <li>
              <Link to={`/info/${user.id}`}>Info</Link>
            </li>
            <li>
              <Link to={`/todos/${user.id}`}>Todos</Link>
            </li>
            <li>
              <Link to={`/posts/${user.id}`}>Posts</Link>
            </li>
            <li>
              <Link to={`/albums/${user.id}`}>Albums</Link>
            </li>
            
            <button id='#logout' onClick={handleLogout}>Logout</button>

          </ul>
        </nav>

        <h1>Welcome, {user.name}!</h1>
        
      </div>
    );
  }

  export default ApplicationPage;



//   <Route path="/todos/:userId">
//   {/* <UserTodos /> */}
// </Route>
// <Route path="/posts/:userId">
//   {/* <UserPosts /> */}
// </Route>
// <Route path="/albums/:userId">
//   {/* <UserAlbums /> */}
// </Route>
// <Route path="/">
//   <h2>Select an option from the navigation menu</h2>
// </Route>