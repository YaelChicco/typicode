import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';

//import './albums.css';


function UserAlbums() {
  const [albums, setAlbums] = useState(null);

  const userId=JSON.parse(localStorage.getItem("username")).id;

  useEffect(() => {
    const fetchAlbums = async () => {
      try {
        const response = await fetch(`https://jsonplaceholder.typicode.com/albums?userId=${userId}`);
        const data = await response.json();
        setAlbums(data);
      } catch (error) {
        console.error(error);
        alert('An error occurred while fetching albums');
      }
    };

    fetchAlbums();
  }, [userId]);



  return (
    <div className='albums'>
      <h2>Albums</h2>
       {albums ? (
        <div className="albums-list">
          {albums.map(album => (
           <div className='album' key={album.id}>
           <Link to={`/albums/${album.id}`}>
                <h3 className='album-title'>{album.title}</h3>
              </Link>
            </div>
          ))}
        </div>
      ) : (
        <p>Loading albums...</p>
      )} 
    </div>
  );
}

export default UserAlbums;
