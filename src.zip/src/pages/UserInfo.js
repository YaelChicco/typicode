import { useState } from "react";

function UserInfo() {

    const [user, setUser] = useState(JSON.parse(localStorage.getItem('username')));
  
    return (
      <div>
        {user ? (
          <div>
            <h2>{user.name}</h2>
            <p>{user.email}</p>
            <p>{user.phone}</p>
            <p>{user.website}</p>
          </div>
        ) : (
          <p>Loading user data...</p>
        )}
      </div>
    );
  }
  
  
  export default UserInfo;