function NotFound(){
    return (
        <h2>Not Found</h2>
    );
}


export default NotFound;
